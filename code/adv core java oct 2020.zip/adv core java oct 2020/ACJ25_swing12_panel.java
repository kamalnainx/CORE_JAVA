// import java.awt.*;
// import javax.swing.*;

// /**
//  * ACJ25_swing12_panel
//  */
// public class ACJ25_swing12_panel
// {
//     ACJ25_swing12_panel()
//     {
//         JFrame jf1= new JFrame("j panel frame");

//         JPanel jp1=new JPanel();
//         jp1.setBounds(50,50,300,300);
//         jp1.setBackground(Color.RED);

//         jf1.add(jp1);
//         jf1.setSize(500,500);
//         jf1.setLayout(null);
//         jf1.setVisible(true);
//     }
//     public static void main(String[] args)
//     {
//         ACJ25_swing12_panel acj25_1=new ACJ25_swing12_panel();
//     }

// }





















// import java.awt.*;
// import javax.swing.*;

// /**
//  * ACJ25_swing12_panel
//  */
// public class ACJ25_swing12_panel {
//     ACJ25_swing12_panel() {
//         JFrame jf1 = new JFrame("j panel frame");

//         JPanel jp1 = new JPanel();
//         jp1.setBounds(50, 50, 300, 300);
//         jp1.setBackground(Color.RED);

//         JButton jb1 = new JButton("button one");
//         jb1.setBackground(Color.GREEN);
//         jb1.setBounds(100, 100, 70, 30);
//         jp1.add(jb1);

//         jf1.add(jp1);
//         jf1.setSize(500, 500);
//         jf1.setLayout(null);
//         jf1.setVisible(true);
//     }

//     public static void main(String[] args) {
//         ACJ25_swing12_panel acj25_1 = new ACJ25_swing12_panel();
//     }

// }
