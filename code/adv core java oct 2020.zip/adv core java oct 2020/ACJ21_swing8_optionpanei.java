// import javax.swing.*;
// /**
//  * ACJ21_swing8_optionpanei
//  */
// public class ACJ21_swing8_optionpanei
// {
//     JFrame j;
//     ACJ21_swing8_optionpanei()
//     {
//         j=new JFrame();
//         JOptionPane.showMessageDialog(j, "message, title, messageType");
//     }
//     public static void main(String[] args)
//     {
//         ACJ21_swing8_optionpanei acj_21 = new ACJ21_swing8_optionpanei();
//     }   
// }












// import javax.swing.*;
// /**
//  * ACJ21_swing8_optionpanei
//  */
// public class ACJ21_swing8_optionpanei
// {
//     JFrame j;
//     ACJ21_swing8_optionpanei()
//     {
//         j=new JFrame();
//         JOptionPane.showMessageDialog(j, "message, title, messageType","Alert",JOptionPane.WARNING_MESSAGE);
//     }
//     public static void main(String[] args)
//     {
//         ACJ21_swing8_optionpanei acj_21 = new ACJ21_swing8_optionpanei();
//     }   
// }














// import javax.swing.*;
// /**
//  * ACJ21_swing8_optionpanei
//  */
// public class ACJ21_swing8_optionpanei
// {
//     JFrame j;
//     ACJ21_swing8_optionpanei()
//     {
//         j=new JFrame();
//         String User_name=JOptionPane.showInputDialog(j, "Please Enter your name");
//     }
//     public static void main(String[] args)
//     {
//         ACJ21_swing8_optionpanei acj_21 = new ACJ21_swing8_optionpanei();
//     }   
// }
