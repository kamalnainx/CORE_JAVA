// import javax.swing.*;
// /**
// * ACJ21_swing7_table
// */
// public class ACJ21_swing7_table
// {
// JFrame jf1;

// ACJ21_swing7_table() {
// jf1 = new JFrame();
// String tabledata[][] =
// {
// { "1", "firstname", "10" }, { "2", "2ndname", "20" }, { "3", "3rdname", "30"
// },
// { "4", "4thname", "40" } };
// String column_head[] = { "sno", "name", "age" };
// JTable jt1 = new JTable(tabledata, column_head);
// jt1.setBounds(40, 40, 300, 300);
// JScrollPane jsp1 = new JScrollPane(jt1);

// jt1.add(jsp1);
// jf1.setSize(400, 400);

// jf1.setVisible(true);
// }

// public static void main(String[] args)
// {
// ACJ21_swing7_table acj21 = new ACJ21_swing7_table();
// }

// }