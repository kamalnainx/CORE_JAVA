// import javax.swing.*;
// /**
//  * ACJ22_swing10_slider
//  */
// public class ACJ22_swing10_slider extends JFrame
// {
//     public ACJ22_swing10_slider()
//     {
//         JSlider js1=new JSlider(JSlider.HORIZONTAL,0,100,50);
//         JPanel jp1=new JPanel();
//         jp1.add(js1);
//         add(jp1);
//     }
//     public static void main(String[] args)
//     {
//         ACJ22_swing10_slider acj22_1 = new ACJ22_swing10_slider();
//         acj22_1.pack();
//         acj22_1.setVisible(true);
//     }

// }


































// import javax.swing.*;

// /**
//  * ACJ22_swing10_slider
//  */
// public class ACJ22_swing10_slider extends JFrame {
//     public ACJ22_swing10_slider() {
//         JSlider js1 = new JSlider(JSlider.HORIZONTAL, 0, 100, 50);
//         js1.setMinorTickSpacing(5);
//         js1.setMajorTickSpacing(10);
//         js1.setPaintTicks(true);
//         js1.setPaintLabels(true);
//         JPanel jp1 = new JPanel();
//         jp1.add(js1);
//         add(jp1);
//         pack();
//         setVisible(true);
//     }

//     public static void main(String[] args) {
//         ACJ22_swing10_slider acj22_1 = new ACJ22_swing10_slider();

//     }

// }
