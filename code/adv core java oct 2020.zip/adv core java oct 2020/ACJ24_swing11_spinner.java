// import javax.swing.*;

// /**
//  * ACJ22_swing11_spinner
//  */
// public class ACJ23_swing11_spinner {
//     public static void main(String[] args) {
//         JFrame f1 = new JFrame("f1");
//         SpinnerModel sm1 = new SpinnerNumberModel(1, 1, 12, 1);
//         JSpinner js1 = new JSpinner(sm1);
//         js1.setBounds(100,100,50,50);
//         f1.add(js1);
//         f1.setSize(500,550);
//         f1.setLayout(null);
//         f1.setVisible(true);
//     }
// }