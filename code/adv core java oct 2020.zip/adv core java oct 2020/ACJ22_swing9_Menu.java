// import javax.swing.*;
// /**
//  * ACJ22_swing9_Menu
//  */
// public class ACJ22_swing9_Menu
// {
//     JMenu menu1;
//     JMenuItem mi1,mi2,mi3,mi4;
//     ACJ22_swing9_Menu()
//     {
//         JFrame jf1= new JFrame();
//         JMenuBar jmb1=new JMenuBar();
//         menu1 = new JMenu("File Menu");
//         mi1=new JMenuItem("New File");
//         mi2=new JMenuItem("open File");
//         mi3=new JMenuItem("save File");
//         mi4=new JMenuItem("exit File");
//         menu1.add(mi1);
//         menu1.add(mi2);
//         menu1.add(mi3);
//         menu1.add(mi4);
//         jmb1.add(menu1);
//         jf1.setJMenuBar(jmb1);
//         jf1.setSize(500,500);
//         jf1.setLayout(null);
//         jf1.setVisible(true);        
//     }

//     public static void main(String[] args)
//     {
//         ACJ22_swing9_Menu acj22_1=new ACJ22_swing9_Menu();
//     }
    
// }















// import javax.swing.*;
// /**
//  * ACJ22_swing9_Menu
//  */
// public class ACJ22_swing9_Menu
// {
    
//     JMenuItem mi1,mi2,mi3,mi4;
//     ACJ22_swing9_Menu()
//     {
//         JFrame jf1= new JFrame();
//         JMenuBar jmb1=new JMenuBar();
 
//         JMenu menu1 = new JMenu("File Menu");
//         mi1=new JMenuItem("New File");
//         mi2=new JMenuItem("open File");
//         mi3=new JMenuItem("save File");
//         mi4=new JMenuItem("exit File");
//         menu1.add(mi1);
//         menu1.add(mi2);
//         menu1.add(mi3);
//         menu1.add(mi4);

//         JMenu menu2 = new JMenu("Edit Menu");
//         mi1=new JMenuItem("Undo File");
//         mi2=new JMenuItem("Redo File");
//         mi3=new JMenuItem("copy File");
//         mi4=new JMenuItem("Cut File");
//         menu2.add(mi1);
//         menu2.add(mi2);
//         menu2.add(mi3);
//         menu2.add(mi4);

//         jmb1.add(menu1);
//         jmb1.add(menu2);
        
//         jf1.setJMenuBar(jmb1);
        
//         jf1.setSize(500,500);
//         jf1.setLayout(null);
//         jf1.setVisible(true);        
//     }

//     public static void main(String[] args)
//     {
//         ACJ22_swing9_Menu acj22_1=new ACJ22_swing9_Menu();
//     }    
// }























// import javax.swing.*;
// /**
//  * ACJ22_swing9_Menu
//  */
// public class ACJ22_swing9_Menu
// {
    
//     JMenuItem mi1,mi2,mi3,mi4;
//     ACJ22_swing9_Menu()
//     {
//         JFrame jf1= new JFrame();
//         JMenuBar jmb1=new JMenuBar();
 
//         JMenu menu1 = new JMenu("File Menu");
//         mi1=new JMenuItem("New File");
//         mi2=new JMenuItem("open File");

//         JMenu jsubm1= new JMenu("save option");
        
//         mi3=new JMenuItem("save File");
//         JMenuItem mi5=new JMenuItem("save as file");

//         mi4=new JMenuItem("exit File");
//         menu1.add(mi1);
//         menu1.add(mi2);
//         jsubm1.add(mi3);
//         jsubm1.add(mi5);
//         menu1.add(jsubm1);
//         menu1.add(mi4);
        

//         JMenu menu2 = new JMenu("Edit Menu");
//         mi1=new JMenuItem("Undo File");
//         mi2=new JMenuItem("Redo File");
//         mi3=new JMenuItem("copy File");
//         mi4=new JMenuItem("Cut File");
//         menu2.add(mi1);
//         menu2.add(mi2);
//         menu2.add(mi3);
//         menu2.add(mi4);

//         jmb1.add(menu1);
//         jmb1.add(menu2);
        
//         jf1.setJMenuBar(jmb1);
        
//         jf1.setSize(500,500);
//         jf1.setLayout(null);
//         jf1.setVisible(true);        
//     }

//     public static void main(String[] args)
//     {
//         ACJ22_swing9_Menu acj22_1=new ACJ22_swing9_Menu();
//     }    
// }
