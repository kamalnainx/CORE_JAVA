
import java.net.InetAddress;
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import java.lang.*;

import mypack.Print_Alphabets;

/**
 * Project
 */
public class Project 
{

    public static void main(String[] args) throws Exception 

    {
        int key;
            
        System.out.println("\n\n\n-----------------------------------------   Enter Your Choice !  ------------------------------------------\n");
        System.out.println(" 1. Fibonacci series\n 2. Palindrome number\n 3. Print_Alphabet\n 4. login_form\n 5. IP_Address\n \n0. Exit");

        
        Scanner scn = new Scanner(System.in);
        key = scn.nextInt();

        switch (key) 
        {
            case 1:
                Fibonacci();
                break;
            
            case 2:
                Palindrome();
                break;

            case 3:
                Print_Alphabet();
                break;

            case 4:
                login_form();
                break;

            case 5:
                IPAddress();
                break;

            case 0:
                exit();
                break;

            default:
                System.out.println("Invalid Option !");
                break;

        }
        while (true)
        {
            main(args);
        }
        
    }
 

    /**-------------------------------------- Function Defination ----------------------------------------------------------------------- */
    public static void Fibonacci()  
    { 
     System.out.println("\nNOTE* :- In fibonacci series, next number is the sum of previous two numbers. \n\t\t for example 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55 etc. The first two numbers of fibonacci series are 0 and 1. \n\t\t You can give any two Numbers of Your choice !\n");
     
     Scanner scn = new Scanner(System.in);   
     int n1,n2,n3=0,i,count=10;    
     System.out.println("enter the Two values");
     n1 = scn.nextInt();
     n2 = scn.nextInt();
     System.out.println("\n");
     System.out.print("Series :-  "+n1+" "+n2);//printing 0 and 1 
        
     for(i=2;i<count;++i)//loop starts from 2 because 0 and 1 are already printed    
     {    
      n3=n1+n2;    
      System.out.print(" "+n3);    
      n1=n2;    
      n2=n3;    
     }    
     
    }


 
    public static void Palindrome()
    {  
     System.out.println("\nNOTE* :- Palindrome number in java: A palindrome number is a number that is same after reverse.\n\t\t For example 545, 151, 34543, 343, 171, 48984 are the palindrome numbers. ");
     int n,r,sum=0,temp;    
     Scanner scn = new Scanner(System.in);
     System.out.println("\nenter a number :-  ");
     n=scn.nextInt();
         
     temp=n;    
     while(n>0) // Reverse the number
     {    
      r=n%10;  //getting remainder  
      sum=(sum*10)+r;    
      n=n/10;    
     }    
     if(temp==sum)    
           System.out.println("\npalindrome number ");    
    else    
          System.out.println("\nnot palindrome");   
          
    }  

    public static void Print_Alphabet()
    {   
        int i=0;
        System.out.println("NOTE* :- It is a program which displays the alphabets in STAR PATTERN, when user inputs the alphabets in capital letters.\n\t\t EXAMPLE : A\n\t\t It allows the 3 Chances to the user to input and see the results.\n ");
       while(i<3)
       {
        Print_Alphabets obj = new Print_Alphabets();
        Print_Alphabets.main(null);
        i++;
       }
 
     
    }  


    public static void login_form() 
    {
        System.out.println("NOTE* :- It is a simple login form in GUI using java");
        
        Frame frm=new Frame("DataEntry frame");
        Label lbl = new Label("Please fill this blank:");
        frm.add(lbl);
        frm.setSize(340,200);
        frm.setVisible(true);
        frm.addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
            System.exit(0);
            }
        });
        Panel p = new Panel();
        Panel p1 = new Panel();
        Label jFirstName = new Label("First Name");
        TextField lFirstName = new TextField(20);
        Label jLastName =new Label("Last Name");
        TextField lLastName=new TextField(20);
        p.setLayout(new GridLayout(3,1));
        p.add(jFirstName);
        p.add(lFirstName);
        p.add(jLastName);
        p.add(lLastName);
        Button Submit=new Button("Submit");
        p.add(Submit);
        p1.add(p);
        frm.add(p1,BorderLayout.NORTH);
        }

 
      
    public static void IPAddress() throws Exception 
    {
        System.out.println("\nIt is the Program to check the system IP_ADDRESS.");
        // Returns the instance of InetAddress containing
        // local host name and address
        InetAddress localhost = InetAddress.getLocalHost();
        System.out.println("\nSystem IP Address : " + (localhost.getHostAddress()).trim());
    }

    public static void exit() 
    {
        System.out.println("\n\n---------------------------- ---------------------                Bye  Bye            ----------------------- ----------------------------------------");
        System.exit(0);
    }
}